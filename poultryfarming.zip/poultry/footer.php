<!-- footer -->
      <footer class="text-white pt-4 pb-1">
        <div class="row justify-content-evenly">
        
          
          <div class="col-md-3 ms-5 flex flex-column">
            <h3>Contact us</h3>
            <div class="flex-row"><i class="bi bi-geo-alt pe-2"></i>
            <p>Poultry Farming,<br> aurangabad</p>
          </div>
            <div class="flex-row">
              <i class="bi bi-telephone pe-2"></i>
              <p>9876543210</p>
            </div>
            <div class="flex-row">
              <i class="bi bi-envelope pe-2"></i>
              <p>poultryfarming@gmail.com</p>
            </div>
          </div>
          <div class="col-md-3 ms-5">
            <h3>Links</h3>
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item text">
                <a class="nav-link active" aria-current="page" href="index.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="About.php">About</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Education.php">Education</a>
              </li><li class="nav-item">
                <a class="nav-link" href="Contact.php">Contact us</a>
              </li>
            </ul>
          </div>
          <div class="col-md-3 ms-5 ">
            <h3>Follow us</h3>
              <a href="https://www.facebook.com/vinodjarae" class="text-white"><h4><i class="bi bi-facebook"></i></h4></a>
              <a href="https://www.instagram.com/vinodjarare" class="text-white"><h4><i class="bi bi-instagram"></i></h4></a>
              <a href="https://github.com/vinodjarare/Poultry-Farming" class="text-white"><h4><i class="bi bi-github"></i></h4></a>
          </div>
        </div>
        <p class="text-center pt-2">copyright &copy 2022 Poultry Farming All Rights Reserved | Privacy Policy</pclass=text-center>
      </footer>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" ></script>
</body>
</html>